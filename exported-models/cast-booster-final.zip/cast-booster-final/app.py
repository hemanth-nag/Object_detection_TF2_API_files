from flask import Flask, render_template, Response, request
import booster_counter_ObjDetect_threads
import sys
import time
import threading
import webbrowser
from datetime import date, datetime

app = Flask(__name__)

counter = None

@app.route('/')
def index():
    return render_template('index.html')

def open_browser():
    #time.sleep(5)
    webbrowser.open_new('http://127.0.0.1:5000/')    

@app.route('/video_feed',methods=['POST','GET'])
def video_feed():
    try:
        return Response(counter.flask_begin("solarcast-p-40gms"), mimetype='multipart/x-mixed-replace; boundary=frame')
    except:
        pass

@app.route('/start',methods=['POST','GET'])
def start():
        global counter
        counter = booster_counter_ObjDetect_threads.main()
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        current_date = now.strftime("%d-%m-%Y")
        q1 = f"INSERT INTO status_capture_castbooster(start_date, start_time, flag) VALUES (TO_DATE('{current_date}', 'DD-MM-YYYY'),'{current_time}', 'TRUE') "
        counter.database.cursor.execute(q1)
        counter.database.con.commit()
        return render_template('index.html')
        #counter.begin("solarcast-p-40gms")

    
@app.route('/stop',methods=['POST','GET'] )
def stop():
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    current_date = now.strftime("%d-%m-%Y")
    q1 = f"UPDATE status_capture_castbooster SET stop_date=TO_DATE('{current_date}', 'DD-MM-YYYY'), stop_time = '{current_time}', flag = 'FALSE' where id=(select id from status_capture_castbooster ORDER BY id DESC LIMIT 1)"
    counter.database.cursor.execute(q1)
    counter.database.con.commit()
    counter.stop()
    return render_template('index.html')



if __name__ == '__main__':
    t1=threading.Thread(target=open_browser)
    t1.start()
    app.run()      