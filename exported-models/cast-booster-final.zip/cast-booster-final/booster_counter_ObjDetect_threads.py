#https://docs.aws.amazon.com/textract/latest/dg/examples-extract-kvp.html
'''
Description
-----------
- This is a simple script I made which calculates the number
  of Boosters in the given image. The script obtains gets the
  images from the Images folder, the calculates the number of
  pieces in the box, shows the output in the terminal and then
  saves them in the Output Images folder(1.jpg, 2.jpg ...n.jpg).
- If the Video is given as input then scripts converts it to image
  and does the processing accordingly.
'''

import cv2
import os
import pyodbc
import psycopg2
import winsound
import threading
import keyboard
import boto3
import re
import sys
import datetime
import colorama
import time

import numpy as np
import tensorflow as tf
import cv2
import time
import os
import imutils
from collections import Counter
from imutils import paths
from object_detection.utils import ops as utils_ops
from object_detection.utils import label_map_util
from object_detection.utils import visualization_utils as viz_utils
#from utils import send_data

from utils.capture_thread import Capture

from datetime import date
from time import strftime

# patch tf1 into `utils.ops`
utils_ops.tf = tf.compat.v1

# Patch the location of gfile
tf.gfile = tf.io.gfile

import numpy as np
import pandas as pd

from flask import Flask, render_template, request,Response
from utils.side_box_detection import isThere
from datetime import date
from datetime import datetime, timedelta
from colorama import Fore
from colorama import Style

#Library Initializations
colorama.init()

#os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "rtsp_transport;udp"

class DataExtractor(object):
    
    '''
    Description
    -----------
    - This Class will be used to Extract the text data from
      a box image.

    '''
    
    def __init__(self,today = datetime.now()):
        
        ##### Folder Paths #####
        self.path = os.path.abspath(os.path.join('Images'))
        self.op_path = os.path.abspath(os.path.join('Barcode Images'))
        #self.cam = cv2.VideoCapture("rtsp://admin:admin123@10.0.34.139:554/cam/realmonitor?channel=1&subtype=0", cv2.CAP_FFMPEG)
        self.cam = Capture("rtsp://admin:admin123@10.0.34.139:554/cam/realmonitor?channel=1&subtype=0")
        self.cam.startCaptureThread()
        #self.cam.set(cv2.CAP_PROP_BUFFERSIZE, 1)

        ##### AWS Credentials #####
        self.bucket = "qr-code-1"
        self.region = "ap-south-1"
        self.year = str(today.year)

        self.ACCESS_KEY_TEXTRACT = 'AKIA3LOVLG3V2I2HFZPW'
        self.SECRET_KEY_TEXTRACT = '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'

        self.ACCESS_KEY_S3 = "AKIAJ225SQ4TRDKGFXSA"
        self.SECRET_KEY_S3 = "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"

        ##### Constant String Params #####
        self.company = "SOLAR INDUSTRIES INDIA LTD. VILLAGE-CHAKDOM BAZARGAON NAGPUR(MS) INDIA"

        ##### Data Storage #####
        '''
        self.filter_keys = ['Unit Size',
                            'No. Units',
                            'Case No.',
                            'Package No.',
                            'Consignee',
                            'Box Net Weight',
                            'Box Gross Weight',
                            'Manufacturing Date',
                            'Class & Div',
                            'Case Size',
                            'Manufactured By',
                            'PORT OF LOADING',
                            'NEQ']

        self.filter_values = ['400 gms',
                              '24 pcs',
                              'CBH4B - 16952',
                              'CS-05285',
                              '9.60 kg',
                              '10.50 kg',
                              '07-Jun-2021',
                              '1/1.1 D',
                              '350X235X145 MM',
                              '1300131001']

        '''

        self.upload_data = {'Unit Size':'Null',
                            'No. Units':'Null',
                            'Case No.': 'Null',
                            'Consignee':'Null',
                            'Package No.':'Null',
                            'Box Net Weight':'Null',
                            'Box Gross Weight':'Null',
                            'Manufacturing Date':'Null',
                            'Class & Div':'Null',
                            'Case Size': 'Null',
                            'Manufactured By':self.company,
                            'Booster Count':'Null',
                            'Actual Net Weight': 'Null',
                            'Actual Gross Weight':'Null',
                            'Date':'Null',
                            'Time':'Null',
                            'Box Url':'Null',
                            'Barcode Url':'Null',
                            'Flag':'Null',
                            'Serial':'Null'}

        
        ##### Data Extraction Params #####
        self.data = []
        self.keys_obtained = []
        self.values_obtained = []
        self.buffer = ''
        self.data_extracted = {}
        self.null_data = True

        ##### Image Params #####
        self.image = None
        self.byte = None
        self.barcode_image = None
        self.fram = None

        ##### AWS Textract Client #####
        self.client = boto3.client(service_name="textract",
                                   region_name=self.region,
                                   aws_access_key_id=self.ACCESS_KEY_TEXTRACT,
                                   aws_secret_access_key=self.SECRET_KEY_TEXTRACT)
        

    def get_image(self,live_feed:bool):

        '''
        Description
        -----------
        - Returns a frame captured from the live camera feed.

        paramters
        ---------
        - live_feed -> bool
                -- decides whether to capture image from live feed or
                   still static image. If set to True then frame will be
                   captured from live feed. If false static frame will be
                   captured.
        
        Returns
        ----------
        - image -> np.array
             - A BGR Image will be returned.
        '''

        if live_feed == True:
            self.image = self.cam.read()
            #_,buffer = cv2.imencode('.jpg',self.image)
            #self.byte = buffer.tobytes()

            image = self.image.copy()
            image = image[700:1900 , 400: 2300] 
            h, w , _ = image.shape
    
            aspect_ratio = w/h
            h = 400
            w = int(h*aspect_ratio)

            self.frame = cv2.resize(image, (w,h))   
            #cv2.imshow("frame", self.frame)

        else:
            self.image = cv2.imread(self.path,1)
            _,buffer = cv2.imencode('.jpg',self.image)
            self.byte = buffer.tobytes()

        return self.image

    def store_barcode_image(self,reset:bool):
        self.barcode_image = self.get_image(live_feed = True)

    def save_image(self):

        '''
        Description
        -----------
        - Saves the image of barcode or datacard with current 
          date and time.

        paramters
        ---------
        - None
        
        Returns
        ----------
        - None
        '''

        now = datetime.now()
        curr_day = str(now.day) + "_" +  str(now.month) + "_" + str(now.year) + "_" + now.strftime("%H_%M_%S") 

        cv2.imwrite(self.op_path + "/" + curr_day  +  ".jpg", self.image)



    def process_text_detection(self):

          '''
          Description
          -----------
          - Detects the data card and returns its 
            response.

          paramters
          ---------
          - None
        
          Returns
          ----------
          - None
          '''
          self.get_image(live_feed = True) 
          #cv2.imshow("frame", self.frame)
          while(cv2.Laplacian(self.get_image(live_feed=True), cv2.CV_64F).var() < 300):   
            self.get_image(live_feed = True) 
          _,buffer = cv2.imencode('.jpg',self.image[700:1900 , 700: 2300])
          self.byte = buffer.tobytes()

          response = self.client.detect_document_text(Document={'Bytes': self.byte})
            
          return response

            
    def string_matching(self, response):

        '''
        Description
        -----------
        - Finds the text pattern and extracts the data from
          the data card.

        paramters
        ---------
        - None
        
        Returns
        ----------
        - None
        '''

        def b2p(dct):
            result=np.zeros((4,2))
            result[0,0]=dct['Left']
            result[1,0]=dct['Left']+dct['Width']
            result[2,0]=dct['Left']+dct['Width']
            result[3,0]=dct['Left']
            result[0,1]=1.0-dct['Top']
            result[1,1]=1.0-dct['Top']
            result[2,1]=1.0-dct['Top']-dct['Height']
            result[3,1]=1.0-dct['Top']-dct['Height']
            return result

        lines_and_bb = {} 


        image = self.image[700:1900 , 700: 2300].copy()
        for block in response['Blocks']:
            if block['BlockType'] == 'CELL': continue
            if block['BlockType'] == 'PAGE': continue
            if block['BlockType'] == 'TABLE': continue
            if block['BlockType'] == 'WORD': continue
            #if block['BlockType'] == 'LINE': continue

            x=int(b2p(block['Geometry']['BoundingBox'])[0][0] * image.shape[1])
            y=int((1-b2p(block['Geometry']['BoundingBox'])[0][1])* image.shape[0])
            x1=int(b2p(block['Geometry']['BoundingBox'])[2][0]* image.shape[1])
            y1=int((1-b2p(block['Geometry']['BoundingBox'])[2][1])* image.shape[0])
            
            lines_and_bb[block['Text']] = (x,y,x1,y1)
        
        
        pattern = '\d\d\dX\d\d\dX\d\d\d.?MM'
        for s in lines_and_bb:  
            if re.match(pattern, s):
                self.upload_data['Case Size']=s
               #print('Case Size',s)
                

        pattern = '\D\D.?.?[ -].?.?\d\d\d\d\d'
        for s in lines_and_bb:  
            if re.match(pattern, s):
                self.upload_data['Package No.']=s
                #print('Package No.',s)
                
        pattern = '\S\S\S\S\S.*-.*\d\d\d\d\d'
        for s in lines_and_bb:  
            if re.match(pattern, s):
                self.upload_data['Case No.']=s
                if(self.upload_data['Package No.']=='Null' and len(s)>18):
                    a=re.search('\D\D.?[ -].?\d\d\d\d\d', s)
                    if a:
                        self.upload_data['Package No.']= a.group()                   
                #print('Case No.',s)

        pattern = '\d*\\.\w*.*[Kk][go]'
        mass=[]
        for s in lines_and_bb:  
            if re.match(pattern, s):
                #print(s)
                mass.append(float(s[:-2]))
        if(len(mass)>0):
            self.upload_data['Box Net Weight'] = str(min(mass)) + ' kg'
            self.upload_data['Box Gross Weight'] = str(max(mass)) + ' kg'       

        pattern = '[oOg]ms'
        mass=[]
        temp = None
        for s in lines_and_bb:  
            if re.match(pattern, s):
                temp=s
                #print(s)        
                bb= lines_and_bb[temp]
                for s,(x,y,x1,y1) in lines_and_bb.items():
                    if abs(y1-bb[3])<20 and abs(x1-bb[0])<20:
                        #print(s)
                        self.upload_data['Unit Size']=s + ' gms'
                

        pattern = '[op][pc]s'
        mass=[]
        for s in lines_and_bb:  
            if re.match(pattern, s):
                temp1=s
                #print(s)
                bb= lines_and_bb[temp1]
                for s,(x,y,x1,y1) in lines_and_bb.items():
                    if abs(y1-bb[3])<20 and abs(x1-bb[0])<15:
                        #print(s)
                        self.upload_data['No. Units']=s + ' pcs'
                

        pattern = '\d.?/.?1.?\\..?\d ?[0D]'
        for s in lines_and_bb:  
            if re.match(pattern, s):
                s= s[:-1] + 'D'
                self.upload_data['Class & Div']='1/1.1 D'
                #print('Class and Div.',s)

        pattern = '\d*.?-.?\w\w\w.?-.?\d\d\d\d.?'
        for s in lines_and_bb:  
            if re.match(pattern, s):
                now = datetime.now()
                todays_date = str(now.day) + '-' + str(now.month) + '-' + str(now.year)
                self.upload_data['Manufacturing Date']=todays_date
                #print('Manufacturing Date. ',s)        

        pattern = '[Cc][oO0]nsi[go]nee.*'
        adr= []
        for s in lines_and_bb:  
            if re.match(pattern, s):
                temp=s
                #print(s)
                bb= lines_and_bb[temp]
                for s,(x,y,x1,y1) in lines_and_bb.items():
                    if y>bb[1] and abs(x-bb[0])<20 and abs(y1-bb[3])<150:
                        #print(s)
                        adr.append(s)
                self.upload_data['Consignee']= ', '.join(adr)

        pattern = 'M[oa][on]u[1f][oa][oc][f1t]ur[oe]d By.*'
        adr= []
        for s in lines_and_bb:  
            if re.match(pattern, s):
                temp=s
                #print(s)
                bb= lines_and_bb[temp]
                for s,(x,y,x1,y1) in lines_and_bb.items():
                    if y>bb[1] and abs(x-bb[0])<20 and abs(y1-bb[3])<150:
                        #print(s)
                        adr.append(s)
                self.upload_data['Manufactured By']= ', '.join(adr)   

    def extract_data(self):

        '''
        Description
        -----------
        - Returns the extracted data from the datacard.

        paramters
        ---------
        - None
        
        Returns
        ----------
        - None
        '''

        response = self.process_text_detection()

        self.string_matching(response)

        return self.upload_data


    def perform_correction(self,data:dict):

        '''
        Description
        -----------
        - Checks  for null values in data storage and 
          corrects them if possible.

        paramters
        ---------
        - data -> dict
                  dictionary of data should be passed as
                  an argument.
        
        Returns
        ----------
        - data -> {str:str} 
                  Corrected data Storage dictionary is returned
        '''
        
        if( data['Unit Size']=='Null' and data['No. Units']=='Null' and data['Case No.']=='Null' and data['Consignee']=='Null' and data['Package No.']=='Null' and data['Box Net Weight']=='Null' and data['Box Gross Weight']=='Null' and data['Manufacturing Date']=='Null' and data['Class & Div']=='Null' and data['Case Size']== 'Null'):
            self.null_data=True
        else:
            self.null_data = False
        
            if data['Class & Div'] == 'Null':
                data['Class & Div'] = '1/1.1 D'            
                
            
            if data['Box Gross Weight'] == '11.1 kg' or data['Box Net Weight'] == '10.4 kg' or data['Unit Size'] == '200 gms' or data['No. Units'] == '52 pcs':
                data['Unit Size'] = '200 gms'
                data['No. Units'] = '52 pcs'
                data['Box Gross Weight'] = '11.1 kg' 
                data['Box Net Weight'] = '10.4 kg'
                data['Case Size'] = '335X295X150 MM'

            if (data['Unit Size'] == '400 gms' and data['No. Units'] == '30 pcs') or (data['Box Gross Weight'] == '12.8 kg' and data['Box Net Weight'] == '12.0 kg') or (data['Box Gross Weight'] == '12.8 kg' and data['Unit Size'] == '400 gms') or (data['Box Gross Weight'] == '12.8 kg' and data['No. Units'] == '30 pcs') or (data['Unit Size'] == '400 gms' and data['Box Net Weight'] == '12.0 kg') or (data['No. Units'] == '30 pcs' and data['Box Net Weight'] == '12.0 kg') or (data['Case Size'] == '355X295X150 MM' and data['Box Gross Weight'] == '12.8 kg') or (data['Case Size'] == '355X295X150 MM' and data['Box Net Weight'] == '12.0 kg') or (data['Case Size'] == '355X295X150 MM' and data['Unit Size'] == '400 gms') or (data['Case Size'] == '355X295X150 MM' and data['No. Units'] == '30 pcs'):
                data['Unit Size'] = '400 gms'
                data['No. Units'] = '30 pcs'
                data['Box Gross Weight'] = '12.8 kg' 
                data['Box Net Weight'] = '12.0 kg'
                data['Case Size'] = '355X295X150 MM'

            if (data['Unit Size'] == '400 gms' and data['No. Units'] == '24 pcs') or (data['Box Gross Weight'] == '10.5 kg' and data['Box Net Weight'] == '9.6 kg') or (data['Box Gross Weight'] == '10.5 kg' and data['Unit Size'] == '400 gms') or (data['Box Gross Weight'] == '10.5 kg' and data['No. Units'] == '24 pcs') or (data['Unit Size'] == '400 gms' and data['Box Net Weight'] == '9.6 kg') or (data['No. Units'] == '24 pcs' and data['Box Net Weight'] == '9.6 kg')  or (data['Case Size'] == '350X235X145 MM' and data['Box Gross Weight'] == '10.5 kg') or (data['Case Size'] == '350X235X145 MM' and data['Box Net Weight'] == '9.6 kg') or (data['Case Size'] == '350X235X145 MM' and data['Unit Size'] == '400 gms') or (data['Case Size'] == '350X235X145 MM' and data['No. Units'] == '24 pcs'):
                data['Unit Size'] = '400 gms'
                data['No. Units'] = '24 pcs'
                data['Box Gross Weight'] = '10.5 kg' 
                data['Box Net Weight'] = '9.6 kg'
                data['Case Size'] = '350X235X145 MM'

        return data


    def get_sample_data(self):

        '''
        Description
        -----------
        - Return a dictionary of sample data that can be uploaded
          in a database for testing or debugging purposes.

        paramters
        ---------
        - None
        
        Returns
        ----------
        - dict -> {str}
        '''

        sample_data =  {'Unit Size':'400 gms',
                        'No. Units':'24 pcs',
                        'Case No.': 'CBH4B-02574',
                        'Consignee':'TENEGA KIMIA SDN BHD',
                        'Package No.':'DS-****',
                        'Box Net Weight':'9.60 kg',
                        'Box Gross Weight':'12.60 kg',
                        'Manufacturing Date':'30-06-2021',
                        'Class & Div':'1.1/D',
                        'Case Size': 'XXXXXXXXX',
                        'Manufactured By':self.company,
                        'Booster Count':'Null',
                        'Actual Net Weight':'Null',
                        'Actual Gross Weight':'Null',
                        'Date':'Null',
                        'Time':'Null',
                        'Box Url':'Null',
                        'Barcode Url':'Null',
                        'Flag':'0',
                        'Serial':'0000'}

        return sample_data


    def reset_upload_data(self):

       '''
        Description
        -----------
        - Sets all the values in the data storage to Null. This should
          be called after every iteration.

        paramters
        ---------
        - None
        
        Returns
        ----------
        - None
       '''
       
       self.upload_data = {'Unit Size':'Null',
                           'No. Units':'Null',
                           'Case No.': 'Null',
                           'Consignee':'Null',
                           'Package No.':'Null',
                           'Box Net Weight':'Null',
                           'Box Gross Weight':'Null',
                           'Manufacturing Date':'Null',
                           'Class & Div':'Null',
                           'Case Size': 'Null',
                           'Manufactured By':self.company,
                           'Booster Count':'Null',
                           'Actual Net Weight':'Null',
                           'Actual Gross Weight':'Null',
                           'Date':'Null',
                           'Time':'Null',
                           'Box Url':'Null',
                           'Barcode Url':'Null',
                           'Flag':'Null',
                           'Rec':'Null'}

    def upload_file_to_s3(self,image_file_type: str, file = None, acl = "public-read"):

        '''
        Description
        -----------
        - Uploads the image of data card and box to AWS cloud storage.

        paramters
        ---------
        - image_file_type -> str
                  -- Name of the type of file which should be uploaded
                     (It can be either barcode or box).

        - acl -> str
                 -- 
        
        Returns
        ----------
        - str : String of the link of the image for accessing it in
                AWS Cloud.
        '''

        now = datetime.now()
        unique_name = str(now.day) + "_" +  str(now.month) + "_" + str(now.year) + "_" + now.strftime("%H_%M_%S")

        if image_file_type == 'box':
           #unique_name = self.upload_data.get('Package No.')
           self.aws_path = "cast_booster_info_img/" + unique_name + "_box" + ".jpg"
           cv2.imwrite("box.jpg",file)
           file = open('box.jpg','rb')

        else:
           #unique_name = self.upload_data.get('Package No.')
           self.aws_path = "cast_booster_info_img/" + unique_name + "_barcode" + ".jpg"
           cv2.imwrite("barcode.jpg",self.image)
           file = open('barcode.jpg','rb')            

        s3 = boto3.client('s3', aws_access_key_id=self.ACCESS_KEY_S3,
                          aws_secret_access_key=self.SECRET_KEY_S3)

        acl = "public-read"
        try:
            s3.upload_fileobj(
                file,
                self.bucket,
                self.aws_path,
                ExtraArgs={
                    "ACL": acl
                }
            )
            print(Fore.BLUE + Style.BRIGHT + image_file_type + " " + "Uploaded" + Style.RESET_ALL)
            url = f"https://{self.bucket}.s3.{self.region}.amazonaws.com/{self.aws_path}"

        except Exception as e:
            print("hey")
            print("Error:", e)
            url = None
        return url


class DataFetcher(object):

    '''
    Description
    -----------
    - This Class will be used to fetch data from SQL Local server. The data
      like Net Weight, Gross Weight, date and time will be extracted. This 
      class will also be used for checking if the data fetched is very old,
      old or new. 
      
    Attributes
    ----------
    - None
    
    Methods
    -------
    fetch_data()
    fetch_time()
    compare_date_and_time()
    '''
    
    
    def __init__(self):
             
        self.conn = pyodbc.connect('Driver={SQL Server};'
                                   'Server=.\SQLEXPRESS;'
                                   'Database=SI810R1;'
                                   'Trusted_Connection=yes;')


        self.cursor = self.conn.cursor()


    def fetch_data(self):
        
        '''
        Description
        -----------
        - Fetch the necessary data from the SQL local server.

        paramters
        ---------
        - None
        
        Returns
        ----------
        - Net Weight -> str
        - Gross Weight -> str
        - Serial Number -> str
        - Placing Time -> datetime_str
        - Box Placing Date -> datetime_str
        '''

        current_date, _ = self.fetch_time()
        df = pd.read_sql_query('''SELECT * FROM SI810R1.dbo.MAC_Rec1 where date03 = (?)  order by Time04; ''',self.conn,params=(current_date,))

        if df.empty:
            net_weight = "No net_weight data found as database is empty"
            gross_weight = "No gross weght data found as database is empty" 
            df_date = "Null"
            df_time = "Null"
            ser_no = "No Serial Number No for Null data"

        else:
             net_weight = str(df['Net Wt06'].iloc[-1])
             gross_weight = str(df['Gross Wt07'].iloc[-1])
             ser_no = str(df['Sl.No01'].iloc[-1])

             df_date = df['Date03'].iloc[-1]
             df_time = df['Time04'].iloc[-1]

             current_date,current_time = self.fetch_time()

             df_time = self.compare_date_and_time([df_time,current_time])

        return net_weight, gross_weight,df_date,df_time,ser_no


    def fetch_time(self):
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        current_date = now.strftime("%d-%m-%Y")
        return current_date,current_time

    def compare_date_and_time(self,data:list) -> [str,str]:

        
        '''
        Description
        -----------
        - Finds the time difference in format (H:M:S) between two time
          values which have format (H:M:S)

        paramters
        ---------
        - None
        
        Returns
        ----------
        - Time Difference (df_time) -> dateime.strptime
        '''
        
        df_time = data[0]
        current_time = data[1]

        diff = datetime.strptime(current_time,"%H:%M:%S") - datetime.strptime(df_time,"%H:%M:%S")
    
        if diff.seconds > 180:
           df_time = "Old Data"

        return df_time   
    
        
class Database(object):
    
    '''
    Description
    -----------
    - This Class will be used to Upload the data extracted
      into the correct database.
      
    Attributes
    ----------
    - None
    
    Methods
    -------
    insert_data()
    check_repetition()
    reset_repetition_check()
    '''
    
    def __init__(self):
        
        self.con = psycopg2.connect(database='industry4',
                                    user='castboosteruser',
                                    password='Castbooster@123',
                                    host='solar-grp-blockchain-bonita-postgresql.cvnnwzjfvvc6.ap-south-1.rds.amazonaws.com',
                                    port='5432')

        #### Database Params ####
        '''
        self.con = psycopg2.connect(database='postgres',
                                    user='postgres',
                                    password='solar@123',
                                    host='127.0.0.1',
                                    port='5432')
        '''
        


        self.cursor = self.con.cursor()
        
        self.cursor.execute("SELECT version();")

        self.record = self.cursor.fetchone()
        
        #### Queries ####
        self.query = "INSERT INTO  industrialapp_castbooster(pallet_size,pallet_count,consignee,\
                      case_number,package_number,box_net_weight,box_gross_weight,\
                      manufacturing_date,class_and_div,case_size,booster_count_code,\
                      actual_net_weight,actual_gross_weight,\
                      date_1,time,box_url,barcode_url,flag,ser_no, manufactured_by)"

        #### Data Storage Variables ####
        self.serial_nums = []
        self.serial_num = ""

        #### Truth Varibles ####
        self.repeated = False


    def insert_data(self,data:dict):

        '''
        Description
        ------------
        - The dictionary with following keys in order should
          be passed:
         
          [1.Unit Size
           2.No. Units
           3.Case No.
           4.Consignee
           5.Package No.
           6.Box Net Weight
           7.Box Gross Weight
           8.Manufacturing Date
           9.Class & Div
           10.Case Size
           11.Booster Count
           12.Actual Net Weight
           13.Actual Gross Weight
           14.Date
           15.Time
           16.Box Url
           17.Barcode Url
           18.Flag
           19.Serial
           20.Manufactured By]
        '''
       
        col_1 = data.get('Unit Size')
        col_2 = data.get('No. Units')
        col_3 = data.get('Consignee')
        col_4 = data.get('Case No.')
        col_5 = data.get('Package No.')
        col_6 = data.get('Box Net Weight')
        col_7 = data.get('Box Gross Weight')
        col_8 = data.get('Manufacturing Date')
        col_9 = data.get('Class & Div')
        col_10 = data.get('Case Size')
        col_11 = data.get('Booster Count')
        col_12 = data.get('Actual Net Weight')
        col_13 = data.get('Actual Gross Weight')
        col_14 = date.today().strftime("%Y-%m-%d")
        col_15 = data.get('Time')
        col_16 = data.get('Box Url')
        col_17 = data.get('Barcode Url')
        col_18 = "0"
        col_19 = data.get('Serial')
        col_20 = data.get('Manufactured By')

        null_checker = [col_1, col_2, col_3, col_4,col_5,
                        col_6, col_7, col_8, col_9,col_10]

        all_nulls = all(element == null_checker[0] for element in null_checker)
                
        if all_nulls == True:
            print("Data not Extracted Correctly")
        
        else:
            print("Data Extrated Correcty")
            self.cursor.execute(self.query + "VALUES('"+ col_1 +"','"+col_2+"','"+col_3+"','"+col_4+"','"+col_5+"',\
                                             '"+col_6+"','"+col_7+"','"+col_8+"','"+col_9+"','"+col_10+"',\
                                             '"+col_11+"','"+col_12+"','"+col_13+"', TO_DATE('"+col_14+"', 'YYYY-MM-DD'),'"+col_15+"',\
                                             '"+col_16+"','"+col_17+"','"+col_18+"','"+col_19+"','"+col_20+"' )")


        self.con.commit()

    def check_repetition(self,serial_number:str, package_number:str):
        
        '''
        Description
        -----------
        - Checks if data of particular serial number is repeated
          or not.If the data is repeated then self.repeated flag
          is set to True otherwise it is set as False.

        paramters
        ---------
        - serial_number -> str
                 String which consist of data serial number(XXXX) should
                 be passed as an argument. eg: 5220, 5221...
        
        Returns
        ----------
        repeated -> bool
                 A boolean flag which tells data is repeated or not is 
                 returned.
        '''

        df = pd.read_sql_query('''SELECT * from industrialapp_castbooster ''', self.con)
        
        last_ser_no = df['ser_no'].iloc[-1]
        last_package_no = df['package_number'].iloc[-1]
        
        last_package_no = last_package_no.replace('-', '')
        last_package_no = last_package_no.replace(' ', '')
        package_number = package_number.replace('-','')
        package_number = package_number.replace(' ','')
        
        if serial_number == last_ser_no or package_number == last_package_no:
            self.repeated = True 
        else:
            self.repeated = False
            
        return self.repeated


    def reset_repetition_check(self):

        '''
        Description
        -----------
        - Resets the data repetition check params.

        paramters
        ---------
        - None
        
        Returns
        ----------
        - None
        '''

        self.repeated = False
        self.serial_nums.clear()
        self.serial_num = ""


    def __del__(self):

        '''
        Destructor
        '''

        print("Database object deleted")
        self.cursor.close()
        self.con.close()
        sys.stdout.flush()

    
class ObjectCounter(object):
    
    '''
    Description
    -----------
    - This Class will be used to detect the number of
      similar objects in an Image.
      
    Attributes
    ----------
    - None
    
    Methods
    -------
    get_images()
    get_image()
    convert_gray()
    clean_image()
    maintain_aspect_ratio()
    detect_pieces_in_image()
    convert_gray()
    reset_calc()
    print_count_of_pieces()
    begin()
    save_image()
    '''
    
    def __init__(self):
        
        '''
        Description
        -----------
        - This is a Constructor. This function is executed as soon as 
          the class object is made or initialized.
        '''
        
        ##### Folder Paths #####
        self.path = os.path.abspath(os.path.join('Images'))
        self.op_path = os.path.abspath(os.path.join('Box Images'))
        self.model_path= "model_new/saved_model_new_v3"
        self.PATH_TO_LABELS = "model_new\label_map.pbtxt"
        
        self.model = tf.saved_model.load(self.model_path)
        
        ##### Storage Variables ##### 
        self.images = []
        self.counts = [0, 0, 0, 0, 0, 0]
        self.final_counts = []
        self.data = {}

        ##### Logic Flags #####
        self.stability = False
        self.restart = False
        self.not_executed = True
        self.box_there = False
        self.once_done = False
        self.not_extracted = False
        self.kill = False

        ##### Counter Variables #####
        self.image_counter = 0
        self.count = 0
        self.calculator = 0
        self.image_number = 0
        self.w = 0
        self.h = 0
        self.t1 = 0
        self.t2 = 0
        self.weighing_machine_upload_time = datetime.now()
        
        ##### Time Variables #####
        self.count_start_time = 0.0
        self.count_stop_time = 0.0
        self.data_extract_start_time = 0.0
        self.data_extract_stop_time = 0.0
        self.total_count_time = 0.0
        self.total_data_extract_time = 0.0
        self.place_time = ""
        self.catagory = ""
        
        ##### External Class Objects #####
        #self.cam = cv2.VideoCapture("rtsp://admin:admin123@10.0.34.138:554/cam/realmonitor?channel=1&subtype=0", cv2.CAP_FFMPEG)
        self.cam = Capture("rtsp://admin:admin123@10.0.34.138:554/cam/realmonitor?channel=1&subtype=0")
        self.cam.startCaptureThread()
        #self.cam.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        self.extractor = DataExtractor()
        self.fetcher = DataFetcher()
        self.database = Database()
        
        ##### Threshold Params #####
        self.max_height = 580
        self.max_width = 670
        self.max_val = np.array([10,30,115]) #[6,30,110]
        self.min_val = np.array([255,255,255]) #[255,255,255]
        
        ##### Image Params #####
        self.data = None
        self.image = None
        self.original_image = None
        self.output_image = None
        self.camera_feed = None
        self.gray = None
        self.thresh = None
        self.hsv = None
        self.extraction_switch = False
        self.thread1 = None
        self.train_set_path = os.path.abspath(os.path.join('train_set_clean'))
        
       
    
        ##### Init Output #####
        print(Fore.MAGENTA + Style.BRIGHT + "Model Initialized Successfully" + Style.RESET_ALL)
        sys.stdout.flush()


    def get_image(self):
        
        '''
        Description
        -----------
        - Gets the image from the stored images list when
          passed with valid argument i.

        paramters
        ---------
        - None
        
        Returns
        ----------
        - None
        '''

       
        self.image = self.cam.read()

        if self.image is not None:
            self.original_image = self.image.copy()
            self.camera_feed = self.image.copy()
            self.raw_feed = self.image.copy()

        else:
            self.original_image = None
            print("Video Ended")
            

    def maintain_aspect_ratio(self):
        
        '''
        Description
        -----------
        - Check the if the size of image is right and if
          not then this function resizes the image by maintaining
          its aspect ratio.
        
        Parameters
        ----------
        - None

        Returns
        -------
        - None
        '''

        h, w , _ = self.image.shape
        
        if h > self.max_height and w > self.max_width:
            aspect_ratio = w/h

            h = 400
            w = int(h*aspect_ratio)

            self.image = cv2.resize(self.image, (w,h))
            self.original_image = cv2.resize(self.original_image,(w,h))
            self.camera_feed = cv2.resize(self.camera_feed,(w,h))
            

    def detect_pieces_in_image(self, box:str):
        
        '''
        Description
        -----------
        - Detects the circular boosters in the given images and draws
          a green border around it.
        
        Parameters
        ----------
        - None

        Returns
        -------
        - None
        '''
        #crop = self.raw_feed
        mask = np.zeros(self.raw_feed.shape[:2], dtype="uint8")
        cv2.rectangle(mask, (400, 250), (2000, 1700), 255, -1)
        masked = cv2.bitwise_and(self.raw_feed, self.raw_feed, mask=mask)
        blur_level = cv2.Laplacian(masked, cv2.CV_64F).var() #smaller= more blurred
        crop = masked
        
        if(self.counts[-1]!=0 and self.counts[-1]<45):
            #for 400 gms
            crop = cv2.copyMakeBorder(crop, 477, 477, 655, 655, cv2.BORDER_CONSTANT, None, value = 0)
            crop = cv2.resize(crop, (2592,1944), interpolation = cv2.INTER_AREA)
        self.image = crop.copy()
        #print(blur_level)
        if(blur_level>90):


            t1 = time.time()  
                      
            # The input needs to be a tensor, convert it using `tf.convert_to_tensor`.
            input_tensor = tf.convert_to_tensor(crop)
        
            # The model expects a batch of images, so add an axis with `tf.newaxis`.
            input_tensor = input_tensor[tf.newaxis, ...]
        
            # input_tensor = np.expand_dims(image_np, 0)
            detections = self.model(input_tensor)
        
            # All outputs are batches tensors.
            # Convert to numpy arrays, and take index [0] to remove the batch dimension.
            # We're only interested in the first num_detections.
            num_detections = int(detections.pop('num_detections'))
            detections = {key: value[0, :num_detections].numpy()
                           for key, value in detections.items()}
            detections['num_detections'] = num_detections
        
            # detection_classes should be ints.
            detections['detection_classes'] = detections['detection_classes'].astype(np.int64)
            
            
            scores = detections['detection_scores']
            min_score_thresh= 0.4
            count = 0
            
            
            for i in scores:
                if i > min_score_thresh:
                    count += 1
            t2=time.time()
            #print(t2-t1)       
        else:
            print("Blur image, discarded :",blur_level)
            count = 0
            
        self.counts.pop(0)
        self.counts.append(count)

        



    def get_final_count(self):
        
        '''
        Description
        -----------
        - Prints the output on the python terminal.
        
        Parameters
        ----------
        - i : int
              - prints the output for image with the respective
                index.

        Returns
        -------
         - None
        '''

        max_repeated = max(self.counts,key = self.counts.count)
        self.count = max_repeated

    
    def start_data_extraction(self) :

        '''
        Description
        -----------
        - This function is called when the thread of data
           extraction is started
        
        Parameters
        ----------
        - None

        Returns
        -------
        - None
        '''
        print(Fore.YELLOW + Style.BRIGHT + "Datasheet Extraction Started" + Style.RESET_ALL)
        self.data = self.extractor.extract_data()
        self.data  = self.extractor.perform_correction(self.data)
        print(Fore.GREEN + Style.BRIGHT + "Datasheet Extraction Completed" + Style.RESET_ALL)
        sys.stdout.flush()

    def weighing_machine_upload(self):
        con = self.database.con

        conn = self.fetcher.conn
        cur = self.database.cursor

        query1 = pd.read_sql_query('''select rec_no, time1 from sql_weight_data where date1=(SELECT date1 from sql_weight_data order by date1 desc limit 1) order by time1 desc limit 1''', con)
        d = query1.to_dict()
        last_rec = d['rec_no'][0]
        last_time = d['time1'][0]
        print(last_rec, last_time)
        query2 = pd.read_sql_query(f'''
                                      SELECT [Rec_NO],[Sl.No01],[Date03],[Time04],[Net Wt06] FROM SI810R1.dbo.MAC_Rec1 WHERE Rec_NO>{last_rec}                              
                                   ''' ,conn)

        for i in range(len(query2.index)):

            cur.execute(
                f"INSERT INTO sql_weight_data(rec_no, serial_number, date1, time1, gross_weight) VALUES ('{query2['Rec_NO'][i]}', '{query2['Sl.No01'][i]}', TO_DATE('{query2['Date03'][i]}', 'DD-MM-YYYY'), '{query2['Time04'][i]}', '{query2['Net Wt06'][i]}')")

        con.commit()

    def write_output(self):
        '''
        Description
        -----------
        - Displays the count of of boosters in box
          on the image.
        
        Parameters
        ----------
        - type -> str
               - Type of the input (image or video) 
                 should be passed as argument.

        Returns
        -------
        - None
        '''
            
        if self.count > 10 and self.box_there and self.not_executed ==True:
               t1=time.time()
               self.count = self.counts[-1]
               self.original_image = cv2.rectangle(self.camera_feed ,(30,70),(30+230,60-50),
                                                   (255,255,255),-1)
               
               self.original_image = cv2.putText(self.original_image, "Pallets:" + str(self.count),
                                                (30,60),cv2.FONT_HERSHEY_SIMPLEX,
                                                1.5,(0,0,0),2, cv2.LINE_AA)
               
               self.output_image = self.original_image.copy()
               sample = self.extractor.get_image(live_feed=True)
               #print('exec',self.not_executed)
               if self.not_executed:

                  self.data_extract_start_time = time.time()

                  print(Fore.YELLOW + Style.BRIGHT + "Data extraction thread started" + Style.RESET_ALL)

                  self.start_data_extraction()
                  
                  now = datetime.now()
                  curr_day = str(now.day) + "_" +  str(now.month) + "_" + str(now.year) + "_" + now.strftime("%H_%M_%S") 
                  cv2.imwrite(self.train_set_path + "/" + curr_day  +  ".jpg", self.raw_feed)
                  
                  self.not_executed = False

                  net_weight, gross_weight, df_date, df_time,ser_no = self.fetcher.fetch_data()
                  box_url = self.extractor.upload_file_to_s3(image_file_type = "box", file=self.output_image)
                  barcode_url = self.extractor.upload_file_to_s3(image_file_type = "barcode", file=sample)      
                  
                  self.data['Booster Count'] = str(self.count)
                  self.data['Actual Net Weight'] = net_weight
                  self.data['Actual Gross Weight'] = gross_weight
                  self.data['Date'] = df_date
                  self.data['Time'] = df_time
                  self.data['Box Url'] = box_url
                  self.data['Barcode Url'] = barcode_url
                  self.data['Serial'] = ser_no

                  print(Fore.CYAN + Style.BRIGHT + str(self.data) + Style.RESET_ALL)
                  sys.stdout.flush()

                  repeated = self.database.check_repetition(serial_number = ser_no, package_number = self.data['Package No.'])
                  print("Repeated: ", repeated)
                
                  #if ((repeated!=True and self.extractor.null_data!=True)):
                  self.database.insert_data(self.data)

                  self.extractor.reset_upload_data()
                  self.extractor.save_image()

                  print(Fore.GREEN + Style.BRIGHT + "Averaging Process in now complete. You can remove the box" + Style.RESET_ALL)
                  sys.stdout.flush()
                  t2=time.time()
                  print(t2-t1)
                  
                  T = threading.Thread(target=self.sound)
                  T.setDaemon(True)
                  T.start()
                  
            
        else:
            self.original_image = cv2.rectangle(self.original_image,(30,70),(30+230,60-50),
                                                   (255,255,255),-1)
            
            self.original_image = cv2.putText(self.original_image,"Pallets: " + str(self.calculator),
                                         (500,70),cv2.FONT_HERSHEY_SIMPLEX,
                                          1.5,(0,0,255),3, cv2.LINE_AA)     

    def stop(self):
        self.kill = True

    def sound(self, freq=2000, duration=2000):
        winsound.Beep(freq, duration)
        
    def begin(self, box_type:str):
        
        '''
        Description
        -----------
        - Main Function of the class where everything is executed.
        
        Parameters
        ----------
        - box_type -> str
                      Name of box type should be passed
                      as a argument.

        Returns
        -------
        - None
        '''

        print(Fore.CYAN + Style.BRIGHT + "Model Started" + Style.RESET_ALL)
        sys.stdout.flush()

        while True:
            
           if self.restart == True:
               #self.cam = cv2.VideoCapture("rtsp://admin:admin123@10.0.34.138:554/cam/realmonitor?channel=1&subtype=0", cv2.CAP_FFMPEG)
               if(self.cam.camThread.is_alive()==False):
                    self.cam.startCaptureThread()
               if(self.extractor.cam.camThread.is_alive()==False):
                    self.extractor.cam.startCaptureThread()
               self.restart = False
               self.database.con = psycopg2.connect(database='industry4',
                                    user='castboosteruser',
                                    password='Castbooster@123',
                                    host='solar-grp-blockchain-bonita-postgresql.cvnnwzjfvvc6.ap-south-1.rds.amazonaws.com',
                                    port='5432')
               self.database.cursor = self.database.con.cursor()
               print(Fore.CYAN + Style.BRIGHT + "Program Restarted Successfully" + Style.RESET_ALL) 
               sys.stdout.flush()

           try:
              t1=time.time() 
              #Get the image
              self.get_image()
              sample = self.extractor.get_image(live_feed = True) 

              self.box_there = isThere(sample)
              #print("Box status: ",self.box_there)
            
              #if not self.box_there and self.count<15:
              if self.count<15:
                  self.not_executed = True
                  self.not_extracted = True
                  self.extraction_switch = False
                
              
              #Detect the objects in the image
              self.detect_pieces_in_image(box = box_type)
              
              self.maintain_aspect_ratio()
              
              self.get_final_count()
              cv2.imshow("Count Feed", self.image)
              box = self.box_there and (self.count>15)
              self.camera_feed = cv2.putText(self.camera_feed, "Box there: " + str(box),
                                                (30,60),cv2.FONT_HERSHEY_SIMPLEX,
                                                1.5,(0,255,0),2, cv2.LINE_AA)
              cv2.imshow("Camera Feed", self.camera_feed)
              cv2.imshow("frame", self.extractor.frame)



              #Write the output on the image.
              self.write_output()
              
              
              
              #Save the image.
              self.save_image()
              self.show_output()
                  
              #self.show_output()
                
              #yield (b'--frame\r\n'
                      #b'Content-Type: image/jpeg\r\n\r\n' + open('t.jpg', 'rb').read() + b'\r\n')

              #Display the output.


              t2=time.time()


              
              #print(t2-t1)   
              
              time_now = datetime.now()
              if (self.weighing_machine_upload_time < time_now and self.once_done==False):
                self.weighing_machine_upload()
                self.weighing_machine_upload_time = self.weighing_machine_upload_time + timedelta(hours = 1)
                
              if (self.weighing_machine_upload_time < time_now):
                self.once_done = True
                 
              if ((cv2.waitKey(1) & 0xFF == ord('q')) or self.kill):
                  self.cam.stopCaptureThread()
                  self.extractor.cam.stopCaptureThread()
                  break
                
           except Exception as e: 
                print(Fore.RED + Style.BRIGHT + str(e) + Style.RESET_ALL)
                print(Fore.MAGENTA + Style.BRIGHT + "Resetting Program" + Style.RESET_ALL) 
                sys.stdout.flush()
                self.restart = True
                cv2.destroyAllWindows()
                continue
         
        #Release the camera and close all windows.
        cv2.destroyAllWindows()
        
        
        
    def flask_begin(self, box_type:str):
        
        '''
        Description
        -----------
        - Main Function of the class where everything is executed.
        
        Parameters
        ----------
        - box_type -> str
                      Name of box type should be passed
                      as a argument.

        Returns
        -------
        - None
        '''

        print(Fore.CYAN + Style.BRIGHT + "Model Started" + Style.RESET_ALL)
        sys.stdout.flush()

        while True:
            
           if self.restart == True:
               #self.cam = cv2.VideoCapture("rtsp://admin:admin123@10.0.34.138:554/cam/realmonitor?channel=1&subtype=0", cv2.CAP_FFMPEG)
               if(self.cam.camThread.is_alive()==False):
                    self.cam.startCaptureThread()
               if(self.extractor.cam.camThread.is_alive()==False):
                    self.extractor.cam.startCaptureThread()
               self.restart = False
               self.database.con = psycopg2.connect(database='industry4',
                                    user='castboosteruser',
                                    password='Castbooster@123',
                                    host='solar-grp-blockchain-bonita-postgresql.cvnnwzjfvvc6.ap-south-1.rds.amazonaws.com',
                                    port='5432')
               self.database.cursor = self.database.con.cursor()
               print(Fore.CYAN + Style.BRIGHT + "Program Restarted Successfully" + Style.RESET_ALL) 
               sys.stdout.flush()

           try:
              t1=time.time() 
              #Get the image
              self.get_image()
              sample = self.extractor.get_image(live_feed = True) 

              self.box_there = isThere(sample)
              #print("Box status: ",self.box_there)
            
              #if not self.box_there and self.count<15:
              if self.count<15:
                  self.not_executed = True
                  self.not_extracted = True
                  self.extraction_switch = False
                
              
              #Detect the objects in the image
              self.detect_pieces_in_image(box = box_type)
              
              self.maintain_aspect_ratio()
              
              self.get_final_count()
              #cv2.imshow("Count Feed", self.image)
              box = self.box_there and (self.count>15)
              self.camera_feed = cv2.putText(self.camera_feed, "Box there: " + str(box),
                                                (30,60),cv2.FONT_HERSHEY_SIMPLEX,
                                                1.5,(0,255,0),2, cv2.LINE_AA)
              #cv2.imshow("Camera Feed", self.camera_feed)
              #cv2.imshow("frame", self.extractor.frame)



              #Write the output on the image.
              self.write_output()
              
              
              
              #Save the image.
              self.save_image()
              #self.show_output()
                  
              #self.show_output()
                
              #yield (b'--frame\r\n'
                      #b'Content-Type: image/jpeg\r\n\r\n' + open('t.jpg', 'rb').read() + b'\r\n')

              #Display the output.


              t2=time.time()


              
              #print(t2-t1)   
              
              time_now = datetime.now()
              if (self.weighing_machine_upload_time < time_now and self.once_done==False):
                self.weighing_machine_upload()
                self.weighing_machine_upload_time = self.weighing_machine_upload_time + timedelta(hours = 1)
                
              if (self.weighing_machine_upload_time < time_now):
                self.once_done = True
                 
              if ((cv2.waitKey(1) & 0xFF == ord('q')) or self.kill):
                  self.cam.stopCaptureThread()
                  self.extractor.cam.stopCaptureThread()
                  break
    
              feed = cv2.hconcat([self.camera_feed, self.extractor.frame])
              if self.output_image is not None:
                feed = cv2.hconcat([feed, self.output_image])
              ret, buffer = cv2.imencode('.jpg', feed)
              frame = buffer.tobytes()
              yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
                
           except Exception as e: 
                print(Fore.RED + Style.BRIGHT + str(e) + Style.RESET_ALL)
                print(Fore.MAGENTA + Style.BRIGHT + "Resetting Program" + Style.RESET_ALL) 
                sys.stdout.flush()
                self.restart = True
                cv2.destroyAllWindows()
                continue
         
        #Release the camera and close all windows.
        cv2.destroyAllWindows()    



    def save_image(self,i=None):
        
        '''
        Description
        -----------
        - Saves the output image in the Output Images Folder.
        
        Parameters
        ----------
        - i : int
             - For saving each image.

        Returns
        -------
        - None
        '''

        now = datetime.now()
        curr_day = str(now.day) + "_"  +  str(now.month) + "_" + str(now.year) + "_" + now.strftime("%H_%M_%S")

        if i is not None:
            cv2.imwrite(self.op_path + "/" + str(i)+ ".jpg", self.output_image)

            if cv2.waitKey(0) & 0xFF == ord('q'):
                cv2.destroyAllWindows()

        else:
            if self.stability == True:
               cv2.imwrite(self.op_path + "/" + curr_day + ".jpg", self.output_image)
               self.stability = False

               
            
    def show_output(self):

        '''
        Description
        -----------
        - Displays the output in cv2 window
        
        Parameters
        ----------
        - None

        Returns
        -------
        - None
        '''

        if self.output_image is not None:
            cv2.imshow("Output", self.output_image)

        else:
            pass
            #cv2.destroyWindow("Output")

def main():

    '''
    Main Function
    '''
    
    #Make the Class Objects here.
    counter = ObjectCounter()

    #Begin the counting.
    #counter.begin("solarcast-p-200gms")
    return counter


if __name__ == '__main__':
    main()  